﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vb6callgraph
{
    public class Analyzer
    {
        public class VBMethod
        {
            public string Name { get; set; }
            public Dictionary<string, VBMethod> Callee { get; set; }
            public int StartLine { get; set; }
        }
    }
}
